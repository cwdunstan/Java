import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Base64;

public class readBlockRun implements Runnable {

	private int port;
	private String ip;
	private Blockchain chain;
	private int index;
	
	public readBlockRun(String ip, int port, Blockchain chain, int index){
		this.ip=ip;
		this.port=port;
		this.chain=chain;
		this.index = index;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Socket toServer = new Socket();
		String encodedhash=null;
        try {
			toServer.connect(new InetSocketAddress(ip, port), 2000);
    	    PrintWriter ow = new PrintWriter(toServer.getOutputStream(), true);
    	    
    	    boolean empty = false;
    	    boolean floating = false;
    	    boolean shorty = true;

    	    //MY CHAIN IS EMPTY 
    	    if(chain.getLength()==0){
    	    	empty=true;
    	    	ow.print("cu\n");
            	ow.flush();
    	    }
    	    //NOT EMPTY, BUT SMALLER
    	    if(!empty && chain.getLength()<index){
    	    	Block track = chain.getHead();
    	    	
    	    	//SET TRACK TO BOTTOM BLOCK
    	    	while(track.getPreviousBlock()!=null){
    	    			track=track.getPreviousBlock();
    	    	}
    	    	//FLOATING HEAD SYNDROME
    	    	String previousHash = Base64.getEncoder().encodeToString(track.getPreviousHash());
    	    	if(!previousHash.equals("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=")){
    	    		floating=true;
    	    		ow.print("cu|"+previousHash+"\n");
    	    		ow.flush();
    	    	}
    	    	//IM SHORTER THAN THEM
    	    	else{
    	    		shorty=true;
        	    	ow.print("cu\n");
                	ow.flush();
    	    	}
    	    }
    	    
    	    //read in a block
            ObjectInputStream ois = new ObjectInputStream(toServer.getInputStream());
            Block temp = (Block) ois.readObject();
            
            //MY CHAIN IS EMPTY
            if(empty){
            	chain.setHead(temp);
            	chain.setLength(chain.getLength()+1);
            }
            
            //MY CHAIN IS FLOATING
            if(floating){
    	    	Block track = chain.getHead();
    	    	
    	    	//SET TRACK TO BOTTOM BLOCK
    	    	while(track.getPreviousBlock()!=null){
    	    			track=track.getPreviousBlock();
    	    	}
    	    	track.setPreviousBlock(temp);
    	    	chain.setLength(chain.getLength()+1);
            }
            if(shorty){
            	
            }
	        	        
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


      }
}


